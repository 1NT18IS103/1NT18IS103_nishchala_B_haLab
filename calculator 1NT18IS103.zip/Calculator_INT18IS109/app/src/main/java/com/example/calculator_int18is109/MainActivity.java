package com.example.calculator_int18is109;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    boolean isNewOp =true;
    EditText text;
    String oldNumber,op;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = findViewById(R.id.editText);
    }
    public void numberEvent(View view)
    {
        if(isNewOp)
            text.setText("");
        isNewOp = false;
        String number = text.getText().toString();
        switch (view.getId())
        {
            case R.id.buONE:
                number+="1";
                break;
            case R.id.buTWO:
                number+="2";
                break;
            case R.id.buTHREE:
                number+="3";
                break;
            case R.id.buFOUR:
                number+="4";
                break;
            case R.id.buFIVE:
                number+="5";
                break;
            case R.id.buSIX:
                number+="6";
                break;
            case R.id.buSEVEN:
                number+="7";
                break;
            case R.id.buEIGHT:
                number+="8";
                break;
            case R.id.buNINE:
                number+="9";
                break;
            case R.id.buZERO:
                number+="0";
                break;
            case R.id.buDT:
                number+=".";
                break;
            case R.id.buPM:
                number="-"+number;
                break;
        }
        text.setText(number);
    }
    public  void operatorEvent(View view)
    {
        isNewOp = true;
        oldNumber = text.getText().toString();
        switch(view.getId())
        {
            case R.id.buMINUS: op = "-"; break;
            case  R.id.buPLUS: op ="+"; break;
            case R.id.buD: op = "/"; break;
            case R.id.buSt: op = "*";break;
        }
    }
    public  void equalEvent(View view)
    {
        String newNumber = text.getText().toString();
        double res = 0.0;
        switch(op)
        {
            case "+": res = Double.parseDouble(oldNumber) + Double.parseDouble(newNumber);
                break;
            case "-": res = Double.parseDouble(oldNumber) - Double.parseDouble(newNumber);
                break;
            case "/": res = Double.parseDouble(oldNumber) / Double.parseDouble(newNumber);
                break;
            case "*": res = Double.parseDouble(oldNumber) * Double.parseDouble(newNumber);
                break;

        }
        text.setText(res+"");
        isNewOp = true;
    }
    public void acEvent(View view)
    {
        text.setText("0");
        isNewOp = true;
    }
    public void percentEvent(View view)
    {
        double no = Double.parseDouble(text.getText().toString())/100;
        text.setText(no+"");
        isNewOp =true;
    }
}